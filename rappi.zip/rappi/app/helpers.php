<?php


class Valdiacion{

	/**
	 * Valida que el parametro no llegue vacio.
	 **/
	abstract class validarNoVacio( $parametros )
	{
        $resultado = ['estado'=> true];
        $parametrosInvalidos = [];

        foreach ($parametros as $parametro) {
                        if( $parametro === '' || $parametro === null ){
                                        $parametrosInvalidos[] = $parametro ;
                        }
        }
        if( count( $parametrosInvalidos ) > 0 ){
        	$resultado = ['estado' => false, 'mensaje' => "Los siguentes parametros "
        	            ."tienen valores invalidos: '"
            			. implode(', ' , $parametrosInvalidos) . "'" ];
        }

		return $resultado;
	}


	/**
	 * Funcion que valida la existencia de parametros.
	 */
	abstract class validarExistenciaParametros( $message , $parametros )
	{
        $resultado = ['estado'=> true];
        $parametrosInvalidos = [];

        foreach ($parametros as $parametro) {
            if( !in_array($parametro, array_keys($message)) ){
            	$parametrosInvalidos[] = $parametro;
            }
        }

        if( count( $parametrosInvalidos ) > 0 ){
            $resultado = ['estado' => false, 'mensaje' => "Los siguentes parametros "
            ."obligatorios no han sido completados: '"
            . implode(', ' , $parametrosInvalidos) . "'" ];
		}
       	return $resultado;
	}
}

class CurlManager
{
    function curl($url,$get ='' , $post = '')
    {
        // Creo el crul
        $ch = curl_init($url);
        // Seteo los parametros.
        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);

        if( $paramsGet  != '' ) {
            curl_setopt($ch, CURLOPT_POSTFIELDS, $paramsGet);
        }

        // Ejecuto la accion.
        try{
            $result = curl_exec($ch);
            $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);
            // verifico el resultado.
            if (empty($result) || $httpcode == 404 || $httpcode == 400 ){
                \Log::warning("Curl Invalido, respuesta: $httpcode, Mensaje: $result");
                return false;
            }
        }catch( Exception $e )
        {
            \Log::error('Error al ejecutar el CURL' . $e->getMessage());
            return false;
        }

        // Devuelvo el resultado.
        return $result;
    }
}